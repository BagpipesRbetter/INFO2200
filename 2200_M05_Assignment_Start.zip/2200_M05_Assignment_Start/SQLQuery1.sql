﻿INSERT INTO JellyBellyTable(jellyBellyFlavor, category) values ('A&W Cream
Soda','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('A&W Root
Beer','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Berry Blue','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Blueberry','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Bubble Gum','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Buttered
Popcorn','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Cantaloupe','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Cappuccino','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Caramel
Corn','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Chili Mango','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Chocolate
Pudding','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Cinnamon','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Coconut','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Cotton
Candy','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Crushed
Pineapple','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Dr Pepper','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('French
Vanilla','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Green Apple','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Island
Punch','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Juicy Pear','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Kiwi','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Lemon Drop','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Lemon Lime','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Licorice','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Mango','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Margarita','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Mixed Berry
Smoothie','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Orange
Sherbet','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Peach','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Pina Colada','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Plum','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values
('Pomegranate','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Raspberry','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Red Apple','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sizzling
Cinnamon','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sour Cherry','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Strawberry
Cheesecake','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Strawberry
Daiquiri','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Strawberry
Jam','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sunkist
Lemon','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sunkist
Lime','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sunkist
Orange','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sunkist Pink
Grapefruit','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Sunkist
Tangerine','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Toasted
Marshmallow','Original 50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Top Banana','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Tutti-Fruitti','Original
50')
GO
INSERT INTO JellyBellyTable (jellyBellyFlavor, category) values ('Very Cherry','Original
50')
GO
